from django.contrib import admin


from .models import Mypothole

admin.site.register(Mypothole)